<script>
	/*业务系统菜单*/
	$('#header .pull-right').append('<a href="http://xxx.com" target="_blank">今目标</a>');
	$('#header .pull-right').append('<a href="http://xxx.com" target="_blank">JIRA</a>');
	$('#header .pull-right').append('<a href="http://xxx.com" target="_blank">Wiki</a>');
	$('#header .pull-right').append('<a href="http://xxx/ccnet" target="_blank">CCNET</a>');
	$('#header .pull-right').append('<a href="http://xxx/svntools/password.php" target="_blank">SVN Password</a>');
</script>
